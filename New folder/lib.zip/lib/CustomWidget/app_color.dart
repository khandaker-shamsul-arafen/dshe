

import 'package:flutter/material.dart';

const Color c435c3= Color(0xFFc435c3);
const Color primary=Color(0xFF7F3DAF);
const Color ancent=Color(0xFF683091);
const Color black=Color(0xFF000000);
const Color D3397 =Color(0xFF6D3397);
const Color BBF45 =Color(0xFF3BBF45);
const Color EFE=Color(0xFF539EFE);
const Color FF8600 =Color(0xFFFF8600);
const Color E3399= Color(0xFF6E3399);
