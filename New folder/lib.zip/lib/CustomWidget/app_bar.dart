//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
//
// import 'custom_text.dart';
//
// class MyAppBar extends StatelessWidget {
//
//
//   @override
//   Widget build(BuildContext context) {
//     return PreferredSize(
//       preferredSize: null,
//       child: AppBar(
//         title: Row(
//           mainAxisAlignment: MainAxisAlignment.start,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             Image.asset("image/bangladesh.png",height:AppBar().preferredSize.height-16
//               ,),
//             SizedBox(width: 5,),
//             customtxt(txt: "DSHE", fontweight: FontWeight.w700, size: 20.00),
//             SizedBox(width: 3,),
//             customtxt(txt: "(মাধ্যমিক ও উচ্চশিক্ষা অধিদপ্তর)", fontweight: FontWeight.w400, size: 14.00),
//           ],
//         ),
//
//       ),
//     );
//   }
// }
//
